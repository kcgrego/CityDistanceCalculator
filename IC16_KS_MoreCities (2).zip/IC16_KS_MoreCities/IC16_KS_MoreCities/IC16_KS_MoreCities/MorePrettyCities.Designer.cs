﻿namespace IC16_KS_MoreCities
{
    partial class MorePrettyCities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MorePrettyCities));
            this.departureComboBox = new System.Windows.Forms.ComboBox();
            this.destinationComboBox = new System.Windows.Forms.ComboBox();
            this.departurePictureBox = new System.Windows.Forms.PictureBox();
            this.destinationPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.departureErrorLabel = new System.Windows.Forms.Label();
            this.destinationErrorLabel = new System.Windows.Forms.Label();
            this.citiesImageList = new System.Windows.Forms.ImageList(this.components);
            this.calculateButton = new System.Windows.Forms.Button();
            this.distanceLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.kiloDistanceLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.departurePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.destinationPictureBox)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // departureComboBox
            // 
            this.departureComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.departureComboBox.FormattingEnabled = true;
            this.departureComboBox.Items.AddRange(new object[] {
            "Boston Mass",
            "Chi town (Chicago)",
            "Dallas",
            "Las vegas",
            "Los Angeles",
            "Miami",
            "New Orleans",
            "Toronto",
            "Vancouver \"Canucky Town\"",
            "Washingtub DC"});
            this.departureComboBox.Location = new System.Drawing.Point(40, 78);
            this.departureComboBox.Name = "departureComboBox";
            this.departureComboBox.Size = new System.Drawing.Size(170, 21);
            this.departureComboBox.TabIndex = 0;
            this.departureComboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // destinationComboBox
            // 
            this.destinationComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.destinationComboBox.FormattingEnabled = true;
            this.destinationComboBox.Items.AddRange(new object[] {
            "Boston Mass",
            "Chi town (Chicago)",
            "Dallas",
            "Las vegas",
            "Los Angeles",
            "Miami",
            "New Orleans",
            "Toronto",
            "Vancouver \"Canucky Town\"",
            "Washingtub DC"});
            this.destinationComboBox.Location = new System.Drawing.Point(457, 78);
            this.destinationComboBox.Name = "destinationComboBox";
            this.destinationComboBox.Size = new System.Drawing.Size(170, 21);
            this.destinationComboBox.TabIndex = 1;
            this.destinationComboBox.SelectedIndexChanged += new System.EventHandler(this.destinationComboBox_SelectedIndexChanged);
            // 
            // departurePictureBox
            // 
            this.departurePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.departurePictureBox.Location = new System.Drawing.Point(40, 168);
            this.departurePictureBox.Name = "departurePictureBox";
            this.departurePictureBox.Size = new System.Drawing.Size(170, 140);
            this.departurePictureBox.TabIndex = 2;
            this.departurePictureBox.TabStop = false;
            this.departurePictureBox.Click += new System.EventHandler(this.departurePictureBox_Click);
            // 
            // destinationPictureBox
            // 
            this.destinationPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.destinationPictureBox.Location = new System.Drawing.Point(457, 168);
            this.destinationPictureBox.Name = "destinationPictureBox";
            this.destinationPictureBox.Size = new System.Drawing.Size(170, 140);
            this.destinationPictureBox.TabIndex = 3;
            this.destinationPictureBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(92, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Departure";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(485, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Final Destination";
            // 
            // departureErrorLabel
            // 
            this.departureErrorLabel.AutoSize = true;
            this.departureErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.departureErrorLabel.Location = new System.Drawing.Point(37, 134);
            this.departureErrorLabel.Name = "departureErrorLabel";
            this.departureErrorLabel.Size = new System.Drawing.Size(174, 13);
            this.departureErrorLabel.TabIndex = 6;
            this.departureErrorLabel.Text = "Please choose a departure location";
            // 
            // destinationErrorLabel
            // 
            this.destinationErrorLabel.AutoSize = true;
            this.destinationErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.destinationErrorLabel.Location = new System.Drawing.Point(454, 134);
            this.destinationErrorLabel.Name = "destinationErrorLabel";
            this.destinationErrorLabel.Size = new System.Drawing.Size(180, 13);
            this.destinationErrorLabel.TabIndex = 7;
            this.destinationErrorLabel.Text = "Please choose a destination location";
            // 
            // citiesImageList
            // 
            this.citiesImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("citiesImageList.ImageStream")));
            this.citiesImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.citiesImageList.Images.SetKeyName(0, "boston.jpg");
            this.citiesImageList.Images.SetKeyName(1, "chicago.jpg");
            this.citiesImageList.Images.SetKeyName(2, "dallas.jpg");
            this.citiesImageList.Images.SetKeyName(3, "lasvegas.jpg");
            this.citiesImageList.Images.SetKeyName(4, "losangeles.jpg");
            this.citiesImageList.Images.SetKeyName(5, "miami.jpg");
            this.citiesImageList.Images.SetKeyName(6, "neworleans.jpg");
            this.citiesImageList.Images.SetKeyName(7, "toronto.jpg");
            this.citiesImageList.Images.SetKeyName(8, "vancouver.jpg");
            this.citiesImageList.Images.SetKeyName(9, "washingtondc.jpeg");
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(44, 90);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(80, 27);
            this.calculateButton.TabIndex = 0;
            this.calculateButton.Text = "&Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // distanceLabel
            // 
            this.distanceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distanceLabel.Location = new System.Drawing.Point(25, 39);
            this.distanceLabel.Name = "distanceLabel";
            this.distanceLabel.Size = new System.Drawing.Size(116, 29);
            this.distanceLabel.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.kiloDistanceLabel);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.calculateButton);
            this.groupBox1.Controls.Add(this.distanceLabel);
            this.groupBox1.Location = new System.Drawing.Point(249, 118);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(182, 218);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Distance (miles):";
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(226, 368);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "C&lear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(390, 368);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Km";
            // 
            // kiloDistanceLabel
            // 
            this.kiloDistanceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kiloDistanceLabel.Location = new System.Drawing.Point(25, 166);
            this.kiloDistanceLabel.Name = "kiloDistanceLabel";
            this.kiloDistanceLabel.Size = new System.Drawing.Size(116, 29);
            this.kiloDistanceLabel.TabIndex = 14;
            // 
            // MorePrettyCities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 457);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.destinationErrorLabel);
            this.Controls.Add(this.departureErrorLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.destinationPictureBox);
            this.Controls.Add(this.departurePictureBox);
            this.Controls.Add(this.destinationComboBox);
            this.Controls.Add(this.departureComboBox);
            this.Name = "MorePrettyCities";
            this.Text = "More Pretty Cities";
            this.Load += new System.EventHandler(this.MorePrettyCities_Load);
            ((System.ComponentModel.ISupportInitialize)(this.departurePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.destinationPictureBox)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox departureComboBox;
        private System.Windows.Forms.ComboBox destinationComboBox;
        private System.Windows.Forms.PictureBox departurePictureBox;
        private System.Windows.Forms.PictureBox destinationPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label departureErrorLabel;
        private System.Windows.Forms.Label destinationErrorLabel;
        private System.Windows.Forms.ImageList citiesImageList;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label distanceLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label kiloDistanceLabel;
        private System.Windows.Forms.Label label3;
    }
}

